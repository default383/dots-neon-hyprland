#!/bin/bash

# Obtenemos la lista de redes
res=$(nmcli -t -f SSID dev wifi | sed '/^$/d' | sort -u | wofi -d -p "Seleccionar red:")

# Si cancelas, salimos
if [ -z "$res" ]; then
    exit
fi

# Intentamos conectar
if nmcli dev wifi connect "$res"; then
    notify-send "Wifi" "Conectado a $res"
else
    # Si falla (probablemente por contraseña), abrimos el prompt de contraseña
    pass=$(wofi -d -p "Contraseña para $res:")
    if [ -n "$pass" ]; then
        nmcli dev wifi connect "$res" password "$pass"
        notify-send "Wifi" "Conectado a $res"
    fi
fi
