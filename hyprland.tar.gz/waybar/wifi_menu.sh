#!/bin/bash
# Script para listar redes y conectar usando wofi
notify-send "Buscando redes..."
chosen_ssid=$(nmcli -t -f SSID dev wifi | sed '/^$/d' | sort -u | wofi -d -p "Seleccionar red:")

if [ -n "$chosen_ssid" ]; then
    nmcli dev wifi connect "$chosen_ssid"
    notify-send "Conectando a $chosen_ssid..."
fi
